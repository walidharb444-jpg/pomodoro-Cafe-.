'use server';
/**
 * @fileOverview A Genkit flow for generating AI-powered study nudges.
 *
 * - generateStudyNudge - A function that generates encouraging study tips or motivational quotes.
 * - StudyNudgeInput - The input type for the generateStudyNudge function.
 * - StudyNudgeOutput - The return type for the generateStudyNudge function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const StudyNudgeInputSchema = z
  .object({
    currentTask: z
      .string()
      .optional()
      .describe(
        'The current study task the user is focused on, if available.'
      ),
    studyDurationMinutes: z
      .number()
      .optional()
      .describe('The duration in minutes the user has been studying.'),
    userName: z.string().optional().describe('The name of the user.'),
  })
  .describe('Input for generating a personalized study nudge.');
export type StudyNudgeInput = z.infer<typeof StudyNudgeInputSchema>;

const StudyNudgeOutputSchema = z
  .object({
    message: z.string().describe('An encouraging study tip or motivational quote.'),
  })
  .describe('Output containing the generated study nudge message.');
export type StudyNudgeOutput = z.infer<typeof StudyNudgeOutputSchema>;

export async function generateStudyNudge(
  input: StudyNudgeInput
): Promise<StudyNudgeOutput> {
  return studyNudgeFlow(input);
}

const prompt = ai.definePrompt({
  name: 'studyNudgePrompt',
  input: {schema: StudyNudgeInputSchema},
  output: {schema: StudyNudgeOutputSchema},
  prompt: `You are a friendly and encouraging cat assistant named Purrfect Focus Cafe's mascot. Your goal is to provide a user with a personalized, short (one to two sentences) study tip or motivational quote. Make it warm, cozy, and supportive.\n\n${'{{#if userName}}'}\nHello, ${'{{{userName}}}'}!\n${'{{/if}}'}\n\n${'{{#if currentTask}}'}\nYou're doing great working on "${'{{{currentTask}}}'}".\n${'{{/if}}'}\n\n${'{{#if studyDurationMinutes}}'}\nYou've been focused for ${'{{{studyDurationMinutes}}}'} minutes. Remember to take a short break if you need one to recharge your purr-fect brain!\n${'{{else}}'}\nKeep up the great work!\n${'{{/if}}'}\n\nProvide a single, short, encouraging study tip or motivational quote:`,
});

const studyNudgeFlow = ai.defineFlow(
  {
    name: 'studyNudgeFlow',
    inputSchema: StudyNudgeInputSchema,
    outputSchema: StudyNudgeOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
