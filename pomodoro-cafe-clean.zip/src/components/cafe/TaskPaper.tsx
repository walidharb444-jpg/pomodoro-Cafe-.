
"use client";

import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2, ScrollText } from 'lucide-react';

interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export function TaskPaper() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', text: 'Sip some delicious focus coffee', completed: true },
    { id: '2', text: 'Review lecture notes', completed: false },
  ]);
  const [newTask, setNewTask] = useState('');

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    setTasks([...tasks, { id: Date.now().toString(), text: newTask, completed: false }]);
    setNewTask('');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div className="w-full h-full textured-paper rounded-xl p-6 shadow-xl border border-primary/10 flex flex-col relative overflow-hidden">
      {/* Menu Header Decoration */}
      <div className="absolute top-0 left-0 w-full h-2 bg-primary/10"></div>
      
      <div className="flex items-center space-x-2 mb-6 border-b-2 border-dashed border-primary/20 pb-4">
        <ScrollText className="text-primary w-6 h-6" />
        <h2 className="text-3xl font-headline text-primary tracking-tight">Today's Order</h2>
      </div>

      <form onSubmit={addTask} className="flex gap-2 mb-6">
        <Input 
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new study goal..."
          className="bg-transparent border-primary/20 focus-visible:ring-primary h-11 placeholder:italic"
        />
        <Button type="submit" size="icon" className="h-11 w-11 shrink-0 rounded-lg bg-primary hover:bg-primary/90">
          <Plus />
        </Button>
      </form>

      <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-muted-foreground italic space-y-2">
            <p className="text-lg">Your menu is empty!</p>
            <p className="text-sm">Enjoy a quiet moment of focus.</p>
          </div>
        ) : (
          tasks.map(task => (
            <div 
              key={task.id}
              className="flex items-center justify-between group animate-in fade-in slide-in-from-left-2 border-b border-primary/5 pb-2 last:border-0"
            >
              <div className="flex items-center space-x-3">
                <Checkbox 
                  checked={task.completed} 
                  onCheckedChange={() => toggleTask(task.id)}
                  className="border-primary/30 data-[state=checked]:bg-primary data-[state=checked]:text-white h-5 w-5 rounded-full"
                />
                <span className={`text-lg transition-all duration-300 font-body ${task.completed ? 'line-through text-muted-foreground opacity-50 italic' : 'text-primary/80'}`}>
                  {task.text}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => deleteTask(task.id)}
                className="text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))
        )}
      </div>
      
      <div className="mt-4 pt-4 border-t border-primary/10 text-xs text-muted-foreground flex justify-between italic font-medium uppercase tracking-widest">
        <span>Serving {tasks.filter(t => t.completed).length} goals</span>
        <span>Total order: {tasks.length}</span>
      </div>
    </div>
  );
}
