
"use client";

import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, MessageCircle, Cat as CatIcon, Heart, Music } from 'lucide-react';
import { generateStudyNudge, type StudyNudgeOutput } from '@/ai/flows/ai-powered-study-nudges';
import * as Tone from 'tone';

const REACTIONS = [
  "Nuzzles against your coffee cup... *purrrr*",
  "Blinks slowly at you with affection.",
  "Happy tail flick! You're doing great.",
  "Adjusts his bow-tie and looks focused.",
  "Pushes a tiny imaginary notepad toward you.",
  "Meow! Keep going, human friend!",
  "Stretches his paws and lets out a tiny yawn."
];

export function CatMascot() {
  const [nudge, setNudge] = useState<string | null>("Meow! I'm here to help you stay focused. Click the sparkles for a purr-fect study tip!");
  const [loading, setLoading] = useState(false);
  const [reaction, setReaction] = useState(REACTIONS[0]);
  const [isWiggling, setIsWiggling] = useState(false);

  const playMeow = useCallback(async () => {
    if (Tone.context.state !== 'running') await Tone.start();
    
    // Synthesize a cute "chirp/meow" sound
    const synth = new Tone.MonoSynth({
      oscillator: { type: "sine" },
      envelope: { attack: 0.05, release: 0.3 }
    }).toDestination();
    
    synth.triggerAttackRelease("C5", "8n", undefined, 0.1);
    synth.triggerAttackRelease("E5", "8n", Tone.now() + 0.1, 0.1);
  }, []);

  const handleMascotClick = () => {
    setIsWiggling(true);
    setReaction(REACTIONS[Math.floor(Math.random() * REACTIONS.length)]);
    playMeow();
    setTimeout(() => setIsWiggling(false), 500);
  };

  const handleGetNudge = async (e: React.MouseEvent) => {
    e.stopPropagation(); // Don't trigger mascot click
    setLoading(true);
    try {
      const result: StudyNudgeOutput = await generateStudyNudge({
        userName: "Focus Friend",
        studyDurationMinutes: 25
      });
      setNudge(result.message);
    } catch (error) {
      setNudge("Focus is like a cat... it takes patience! Keep going.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex flex-col items-center justify-center w-full max-w-2xl mx-auto py-8">
      {/* Interactive Mascot Box */}
      <div 
        onClick={handleMascotClick}
        className={`relative w-64 h-64 md:w-80 md:h-80 rounded-3xl overflow-hidden shadow-2xl border-8 border-primary/10 bg-white/50 backdrop-blur-sm cursor-pointer transition-all duration-300 hover:shadow-primary/5 group ${isWiggling ? 'scale-110 rotate-3' : 'hover:scale-105'}`}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className={`relative transition-transform duration-500 ${isWiggling ? 'animate-bounce' : 'cat-float'}`}>
            <CatIcon className="w-32 h-32 md:w-48 md:h-48 text-primary group-hover:text-secondary transition-colors" />
            <div className="absolute -top-4 -right-4">
               <Heart className={`w-8 h-8 text-secondary fill-secondary transition-all duration-500 ${isWiggling ? 'opacity-100 scale-125' : 'opacity-0 scale-50'}`} />
            </div>
          </div>
        </div>

        {/* Aesthetic overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none"></div>
        <div className="absolute top-4 right-4 flex items-center space-x-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg border border-primary/5">
           <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
           <span className="text-[10px] font-bold text-primary uppercase tracking-tighter">Mascot Online</span>
        </div>
        
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-bold text-primary/40 uppercase tracking-widest whitespace-nowrap">
           Click to Pet
        </div>
      </div>

      {/* Reaction / Speech Bubble */}
      <div className="mt-8 relative w-full max-w-lg">
        <div className="bg-white p-6 rounded-2xl shadow-xl border-2 border-primary/5 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-secondary"></div>
          <div className="space-y-4">
            <div className="flex items-start space-x-4 border-b border-primary/5 pb-4">
              <div className="p-2 bg-secondary/30 rounded-full">
                <Music className="h-4 w-4 text-primary" />
              </div>
              <p className="text-primary/70 text-sm italic font-body">
                {reaction}
              </p>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-secondary/50 rounded-full">
                <MessageCircle className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-primary leading-relaxed font-body font-medium">
                  {loading ? "Thinking of something purr-fect..." : nudge}
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
             <Button 
               disabled={loading}
               onClick={handleGetNudge}
               variant="outline" 
               size="sm" 
               className="rounded-full border-secondary text-primary hover:bg-secondary/20 font-bold"
             >
               <Sparkles className={`mr-2 h-4 w-4 text-primary ${loading ? 'animate-spin' : ''}`} /> 
               {loading ? 'GETTING TIP...' : 'GET PURR-FECT TIP'}
             </Button>
          </div>
        </div>
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-white border-l-2 border-t-2 border-primary/5 rotate-45"></div>
      </div>
    </div>
  );
}
