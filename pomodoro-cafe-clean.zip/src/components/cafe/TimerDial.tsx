
"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw, Coffee, Zap, Brain } from 'lucide-react';

export function TimerDial() {
  const [timeLeft, setTimeLeft] = useState(30 * 60);
  const [isActive, setIsActive] = useState(false);
  const [totalTime, setTotalTime] = useState(30 * 60);

  const toggle = () => setIsActive(!isActive);
  const reset = useCallback(() => {
    setIsActive(false);
    setTimeLeft(totalTime);
  }, [totalTime]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const setPreset = (minutes: number) => {
    const seconds = minutes * 60;
    setTotalTime(seconds);
    setTimeLeft(seconds);
    setIsActive(false);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progress = ((totalTime - timeLeft) / totalTime) * 100;

  return (
    <div className="flex flex-col items-center space-y-6">
      <div className="relative flex items-center justify-center">
        {/* Outer Dial Container */}
        <div className="w-64 h-64 md:w-80 md:h-80 rounded-full bg-primary shadow-2xl p-4 wood-texture relative flex items-center justify-center border-8 border-primary/20">
          {/* Progress Ring */}
          <svg className="absolute inset-0 w-full h-full -rotate-90">
            <circle
              cx="50%"
              cy="50%"
              r="45%"
              className="fill-none stroke-secondary/20 stroke-[12]"
            />
            <circle
              cx="50%"
              cy="50%"
              r="45%"
              className="fill-none stroke-secondary stroke-[12] transition-all duration-1000"
              strokeDasharray="283"
              strokeDashoffset={283 - (283 * progress) / 100}
              strokeLinecap="round"
              style={{ strokeDasharray: '565.48', strokeDashoffset: 565.48 - (565.48 * progress) / 100 }}
            />
          </svg>

          {/* Inner Display */}
          <div className="w-[85%] h-[85%] rounded-full bg-white flex flex-col items-center justify-center shadow-inner relative z-10 border-4 border-primary/10">
            <span className="text-xs font-bold text-primary/40 uppercase tracking-widest mb-1">Brewing Focus</span>
            <div className="text-5xl md:text-6xl font-headline text-primary tracking-tighter">
              {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
            </div>
            <div className="flex space-x-2 mt-4">
              <Button size="icon" variant="ghost" onClick={toggle} className="hover:bg-secondary rounded-full">
                {isActive ? <Pause className="text-primary" /> : <Play className="text-primary fill-primary" />}
              </Button>
              <Button size="icon" variant="ghost" onClick={reset} className="hover:bg-secondary rounded-full">
                <RotateCcw className="text-primary" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-3">
        <Button 
          onClick={() => setPreset(30)} 
          variant={totalTime === 30 * 60 ? 'default' : 'outline'}
          className="rounded-full px-6 font-bold"
        >
          <Brain className="mr-2 h-4 w-4" /> 30 MIN
        </Button>
        <Button 
          onClick={() => setPreset(10)} 
          variant={totalTime === 10 * 60 ? 'default' : 'outline'}
          className="rounded-full px-6 font-bold"
        >
          <Zap className="mr-2 h-4 w-4" /> 10 MIN
        </Button>
        <Button 
          onClick={() => setPreset(5)} 
          variant={totalTime === 5 * 60 ? 'default' : 'outline'}
          className="rounded-full px-6 font-bold"
        >
          <Coffee className="mr-2 h-4 w-4" /> 5 MIN
        </Button>
      </div>
    </div>
  );
}
