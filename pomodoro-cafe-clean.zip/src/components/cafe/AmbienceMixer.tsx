
"use client";

import React, { useState, useEffect, useRef } from 'react';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Volume2, VolumeX, CloudRain, Coffee, Cat, Music, Disc, Zap, Headphones } from 'lucide-react';
import * as Tone from 'tone';

interface SoundControl {
  id: string;
  name: string;
  icon: React.ReactNode;
  isActive: boolean;
  volume: number;
}

export function AmbienceMixer() {
  const [controls, setControls] = useState<SoundControl[]>([
    { id: 'cafe', name: 'Coffee Shop Ambience', icon: <Coffee className="h-4 w-4" />, isActive: false, volume: 40 },
    { id: 'rain', name: 'Rainy Day', icon: <CloudRain className="h-4 w-4" />, isActive: false, volume: 30 },
    { id: 'purr', name: 'Cat Purrs', icon: <Cat className="h-4 w-4" />, isActive: false, volume: 70 },
    { id: 'jazz', name: 'Jazz Cafe Beats', icon: <Disc className="h-4 w-4" />, isActive: false, volume: 35 },
    { id: 'lofi', name: 'Lo-fi Hip Hop Mix', icon: <Headphones className="h-4 w-4" />, isActive: false, volume: 25 },
    { id: 'elevator', name: 'Elevator Music', icon: <Music className="h-4 w-4" />, isActive: false, volume: 20 },
    { id: 'fireplace', name: 'Fireplace', icon: <Zap className="h-4 w-4" />, isActive: false, volume: 40 },
  ]);

  const players = useRef<Record<string, any>>({});
  const loops = useRef<Record<string, Tone.Loop | Tone.Sequence>>({});

  useEffect(() => {
    // Purr: Deep rumble
    const purrOsc = new Tone.Oscillator(45, "sine").toDestination();
    const purrLFO = new Tone.LFO(15, -10, 0).connect(purrOsc.volume).start();
    players.current['purr'] = purrOsc;

    // Rain: Pink noise
    const rainNoise = new Tone.Noise("pink").toDestination();
    players.current['rain'] = rainNoise;

    // Coffee Shop: Brown noise (room tone)
    const cafeNoise = new Tone.Noise("brown").toDestination();
    players.current['cafe'] = cafeNoise;

    // Jazz Cafe Beats: Simple walking bass simulation
    const jazzSynth = new Tone.MonoSynth({
      oscillator: { type: "sine" },
      envelope: { attack: 0.1, release: 0.4 }
    }).toDestination();
    const jazzSeq = new Tone.Sequence((time, note) => {
      jazzSynth.triggerAttackRelease(note, "8n", time);
    }, ["C2", "E2", "G2", "A2"], "4n");
    players.current['jazz'] = jazzSynth;
    loops.current['jazz'] = jazzSeq;

    // Lo-fi Hip Hop: Filtered pink noise with a slow pulse
    const lofiNoise = new Tone.Noise("pink");
    const lofiFilter = new Tone.Filter(400, "lowpass").toDestination();
    lofiNoise.connect(lofiFilter);
    players.current['lofi'] = lofiNoise;

    // Elevator Music: Simple Bossa-ish melody
    const elevatorSynth = new Tone.PolySynth(Tone.Synth, {
      oscillator: { type: "triangle" },
      envelope: { attack: 0.2, release: 1 }
    }).toDestination();
    const elevatorSeq = new Tone.Sequence((time, note) => {
      elevatorSynth.triggerAttackRelease(note, "4n", time);
    }, [["C4", "E4", "G4"], ["A3", "C4", "E4"], ["D4", "F4", "A4"], ["G3", "B3", "D4"]], "2n");
    players.current['elevator'] = elevatorSynth;
    loops.current['elevator'] = elevatorSeq;

    // Fireplace: Low-pass filtered white noise
    const fireNoise = new Tone.Noise("white");
    const fireFilter = new Tone.Filter(200, "lowpass").toDestination();
    fireNoise.connect(fireFilter);
    players.current['fireplace'] = fireNoise;

    return () => {
      Object.values(players.current).forEach(p => {
        if (p.stop) p.stop();
        if (p.dispose) p.dispose();
      });
      Object.values(loops.current).forEach(l => {
        if (l.stop) l.stop();
        if (l.dispose) l.dispose();
      });
    };
  }, []);

  const handleToggle = async (id: string) => {
    if (Tone.context.state !== 'running') {
      await Tone.start();
    }

    const updated = controls.map(c => {
      if (c.id === id) {
        const newState = !c.isActive;
        const player = players.current[id];
        const loop = loops.current[id];
        
        if (player) {
          if (newState) {
            player.volume.value = Tone.gainToDb(c.volume / 100);
            if (player.start) player.start();
            if (loop) {
              Tone.Transport.start();
              loop.start(0);
            }
          } else {
            if (player.stop) player.stop();
            if (loop) loop.stop();
          }
        }
        return { ...c, isActive: newState };
      }
      return c;
    });
    setControls(updated);
  };

  const handleVolume = (id: string, val: number[]) => {
    const volume = val[0];
    const player = players.current[id];
    if (player) {
      player.volume.value = Tone.gainToDb(volume / 100);
    }
    setControls(controls.map(c => c.id === id ? { ...c, volume } : c));
  };

  return (
    <div className="w-full h-full bg-[#fcfaf7] rounded-xl p-6 shadow-xl border border-primary/10 flex flex-col">
      <div className="flex items-center space-x-2 mb-6 border-b border-primary/10 pb-4">
        <Volume2 className="text-primary w-6 h-6" />
        <h2 className="text-2xl font-headline text-primary uppercase tracking-widest text-sm">Ambience Mixer</h2>
      </div>

      <div className="space-y-6 flex-1 overflow-y-auto pr-2 custom-scrollbar">
        {controls.map((sound) => (
          <div key={sound.id} className="space-y-3 p-3 rounded-xl transition-colors hover:bg-primary/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 text-primary">
                <div className={`p-2 rounded-full transition-all duration-300 ${sound.isActive ? 'bg-secondary text-primary scale-110 shadow-lg' : 'bg-muted/50 text-muted-foreground'}`}>
                  {sound.icon}
                </div>
                <span className="font-bold text-sm uppercase tracking-tight">{sound.name}</span>
              </div>
              <Switch 
                checked={sound.isActive}
                onCheckedChange={() => handleToggle(sound.id)}
                className="data-[state=checked]:bg-primary"
              />
            </div>
            <div className="flex items-center space-x-4 pl-1">
              <VolumeX className="h-3 w-3 text-muted-foreground" />
              <Slider
                disabled={!sound.isActive}
                value={[sound.volume]}
                onValueChange={(val) => handleVolume(sound.id, val)}
                max={100}
                step={1}
                className="flex-1 opacity-80"
              />
              <Volume2 className="h-3 w-3 text-muted-foreground" />
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-secondary/30 rounded-lg border border-secondary/50">
        <p className="text-[10px] font-bold text-primary/70 uppercase tracking-widest text-center">
           Focused Ambience Mix
        </p>
      </div>
    </div>
  );
}
