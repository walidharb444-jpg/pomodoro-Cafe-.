"use client";

import React, { useState } from 'react';

interface DoorEntryProps {
  onEnter: () => void;
}

export function DoorEntry({ onEnter }: DoorEntryProps) {
  const [isEntering, setIsEntering] = useState(false);

  const handleEnter = () => {
    setIsEntering(true);
    setTimeout(onEnter, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center bg-background overflow-hidden selection:bg-secondary">
      {/* Main Container */}
      <div 
        className={`relative w-full h-full flex flex-col items-center pt-12 transition-all duration-[1500ms] cubic-bezier(0.7, 0, 0.3, 1) ${
          isEntering ? 'scale-[4.5] blur-2xl opacity-0' : 'scale-100'
        }`}
      >
        {/* Brand Name & Signature - Positioned above the arch curve */}
        <div className="mb-12 text-center animate-in fade-in slide-in-from-top-4 duration-1000">
          <h1 className="text-4xl md:text-6xl font-headline text-primary tracking-tighter font-medium">
            Promoduro Cafe
          </h1>
          <p className="mt-2 text-xs md:text-sm font-body text-primary/60 tracking-[0.3em] uppercase italic">
            By Rawan
          </p>
        </div>

        {/* Full-Height Arch - Extends to bottom */}
        <div className="relative w-full max-w-2xl h-full rounded-t-full border-x-[12px] border-t-[12px] border-secondary bg-white shadow-[0_-10px_60px_-15px_rgba(247,212,225,0.4)] flex flex-col items-center">
          
          {/* Inner Arch Glow */}
          <div className="absolute inset-0 bg-gradient-to-b from-secondary/5 to-transparent pointer-events-none rounded-t-full"></div>

          {/* Hanging Sign - Positioned at the very top of the arch */}
          <div className="relative mt-8 flex flex-col items-center z-20">
            {/* Very Shortened V-Strings */}
            <svg 
              className="w-24 h-8 text-primary/40" 
              viewBox="0 0 100 20" 
              fill="none" 
            >
              <path 
                d="M50 0 L30 18 M50 0 L70 18" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round"
              />
            </svg>

            {/* The Hanging Sign */}
            <div 
              onClick={handleEnter}
              className="relative w-[160px] h-[90px] md:w-[200px] md:h-[110px] cursor-pointer group -mt-1"
              style={{ transform: 'rotate(-1.8deg)' }}
            >
              <div className="w-full h-full bg-white border-[3px] border-primary rounded-md shadow-[6px_6px_0px_0px_rgba(96,61,38,1)] flex flex-col items-center justify-center transform transition-all duration-500 group-hover:scale-105 group-hover:rotate-0 active:scale-95">
                
                <div 
                  className="absolute inset-2 bg-cover bg-center rounded-sm opacity-5 group-hover:opacity-10 transition-opacity"
                  style={{ backgroundImage: "url('https://picsum.photos/seed/cafe-sign/400/300')" }}
                  data-ai-hint="cafe storefront"
                />

                <span className="relative z-10 text-3xl md:text-5xl font-headline text-primary uppercase tracking-[0.2em] font-black italic">
                  Open
                </span>
                
                <div className="absolute top-2 left-2 w-1.5 h-1.5 rounded-full bg-primary/20"></div>
                <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-primary/20"></div>
              </div>
            </div>
          </div>

          {/* Subtext - Positioned at the bottom of the extended arch */}
          <div className="mt-auto mb-12 text-center px-8 z-10">
            <p className="text-primary/50 font-body italic text-sm md:text-lg animate-pulse tracking-wide">
              Click to step inside
            </p>
          </div>

          {/* Floor Shadow Reflection */}
          <div className="absolute bottom-0 w-full h-32 bg-gradient-to-t from-secondary/10 to-transparent pointer-events-none"></div>
        </div>
      </div>

      {/* Entry Hint Overlay */}
      {!isEntering && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center space-y-1 pointer-events-none opacity-40">
          <span className="text-[10px] font-bold text-primary uppercase tracking-[0.8em]">
            Welcome
          </span>
        </div>
      )}
    </div>
  );
}
