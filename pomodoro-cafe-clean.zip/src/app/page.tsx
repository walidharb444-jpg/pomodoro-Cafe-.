"use client";

import React, { useState } from 'react';
import { DoorEntry } from '@/components/cafe/DoorEntry';
import { TimerDial } from '@/components/cafe/TimerDial';
import { TaskPaper } from '@/components/cafe/TaskPaper';
import { AmbienceMixer } from '@/components/cafe/AmbienceMixer';
import { CatMascot } from '@/components/cafe/CatMascot';
import { Coffee, Settings, Heart } from 'lucide-react';

export default function Home() {
  const [hasEntered, setHasEntered] = useState(false);

  if (!hasEntered) {
    return <DoorEntry onEnter={() => setHasEntered(true)} />;
  }

  return (
    <div className="min-h-screen bg-background relative overflow-x-hidden selection:bg-secondary">
      {/* Background Textures */}
      <div className="fixed inset-0 wood-texture opacity-5 pointer-events-none"></div>
      
      {/* Header */}
      <header className="relative z-10 px-6 py-4 flex items-center justify-between border-b border-primary/10 bg-background/50 backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <div className="bg-primary text-white p-2 rounded-xl">
            <Coffee className="h-6 w-6" />
          </div>
          <h1 className="text-2xl font-headline text-primary tracking-tight">Promoduro Cafe</h1>
        </div>
        <div className="flex items-center space-x-4">
          <button className="text-primary/60 hover:text-primary transition-colors">
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Main Dashboard Layout */}
      <main className="relative z-10 max-w-[1600px] mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Tasks */}
          <div className="lg:col-span-3 h-[calc(100vh-12rem)] min-h-[500px]">
            <TaskPaper />
          </div>

          {/* Center Column: Timer & Mascot */}
          <div className="lg:col-span-6 space-y-8 flex flex-col items-center">
            <div className="w-full animate-in zoom-in-95 duration-700">
              <TimerDial />
            </div>
            <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-300">
              <CatMascot />
            </div>
          </div>

          {/* Right Column: Ambience */}
          <div className="lg:col-span-3 h-[calc(100vh-12rem)] min-h-[500px]">
            <AmbienceMixer />
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 mt-auto py-8 text-center text-primary/40 text-sm italic">
        <p className="flex items-center justify-center">
          Hand-painted with <Heart className="h-3 w-3 mx-1 fill-secondary text-secondary" /> for focused souls.
        </p>
      </footer>
    </div>
  );
}
